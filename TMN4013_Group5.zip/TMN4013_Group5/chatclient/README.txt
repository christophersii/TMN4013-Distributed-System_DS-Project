//Link to the demo video
https://youtu.be/O3c_uOS9hDE

//Listing of the included file names
chatclient folder
    Chat.java
    ChatClient.java
    Chat.class
    ChatClient.class
    README.txt

// Example command of Step to compile, execute and run this program. 
    Open new terminal (machine A)
        cd into chatclient directory
            command: javac *.java
            command: java ChatRoomClient
                enter server <ip address>
                enter server <rmiregistry port number>
                enter username
                enter password
                enter operation

    Open new terminal (machine B)
        cd into chatclient directory
            command: javac *.java
            command: java ChatRoomClient
                enter server <ip address>
                enter server <rmiregistry port number>
                enter username
                enter password
                enter operation

    Open new terminal (machine C)
        cd into chatclient directory
            command: javac *.java
            command: java ChatRoomClient
                enter server <ip address>
                enter server <rmiregistry port number>
                enter username
                enter password
                enter operation